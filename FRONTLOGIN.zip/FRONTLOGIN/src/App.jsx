import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import AuthApp from "./components/AuthApp.jsx";
import HomePage from "./components/HomePage.jsx";
import ChatRoom from "./components/ChatRoom.jsx";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<AuthApp />} />
        <Route path="/home" element={<HomePage />} />
        <Route path="/chat/:roomId" element={<ChatRoom />} />
      </Routes>
    </Router>
  );
}

export default App;
