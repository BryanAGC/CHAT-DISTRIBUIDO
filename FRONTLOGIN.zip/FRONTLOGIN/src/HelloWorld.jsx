export default function HelloWorld() {
    return (
      <div className="hello-world-container">
        <h1>¡Hola Mundo!</h1>
      </div>
    );
  }
  