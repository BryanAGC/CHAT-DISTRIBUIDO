import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

function ChatRoom() {
  const { roomId } = useParams();
  const [sala, setSala] = useState(null);
  const [mensajes, setMensajes] = useState([]);
  const [nuevoMensaje, setNuevoMensaje] = useState("");

  // Obtener datos de la sala
  useEffect(() => {
    fetch(`http://192.168.65.207:4000/api-sala/room/${roomId}`)
      .then((res) => res.json())
      .then((data) => setSala(data))
      .catch((error) => console.error("Error al obtener la sala:", error));
  }, [roomId]);

  // Obtener los mensajes iniciales de la sala
  useEffect(() => {
    fetch(`http://192.168.65.207:4000/api-chat/chat/${roomId}`)
      .then((res) => res.json())
      .then((data) => setMensajes(data))
      .catch((error) => console.error("Error al obtener los mensajes:", error));
  }, [roomId]);

  // Configurar la actualización periódica de los mensajes
  useEffect(() => {
    const interval = setInterval(() => {
      fetch(`http://192.168.65.207:4000/api-chat/chat/${roomId}`)
        .then((res) => res.json())
        .then((data) => setMensajes(data))
        .catch((error) => console.error("Error al obtener los mensajes:", error));
    }, 5000); // Consulta cada 5 segundos

    return () => clearInterval(interval); // Limpiar el intervalo cuando el componente se desmonta
  }, [roomId]);

  // Función para enviar un nuevo mensaje
  const enviarMensaje = async () => {
    if (!nuevoMensaje.trim()) return;

    const username = localStorage.getItem("username");

    if (!username) {
      console.log("Usuario no encontrado");
      return;
    }

    const mensajeData = {
      sender: username,
      content: nuevoMensaje,
      idsala: roomId,
    };

    try {
      const res = await fetch("http://192.168.65.207:4000/api-chat/chat/crear", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(mensajeData),
      });

      if (res.ok) {
        const mensajeEnviado = await res.json();
        setMensajes((prevMensajes) => [...prevMensajes, mensajeEnviado]); // Agregar el nuevo mensaje
        setNuevoMensaje(""); // Limpiar el input
      }
    } catch (error) {
      console.error("Error al enviar el mensaje:", error);
    }
  };

  if (!sala) return <p>Cargando sala...</p>;

  return (
    <div>
      <h2>{sala.name}</h2>
      <p><strong>ID de la Sala:</strong> {sala._id}</p>
      <p><strong>Creada el:</strong> {new Date(sala.createdAt).toLocaleString()}</p>

      <h3>Chat en tiempo real</h3>

      {/* Lista de mensajes */}
      <div style={{ border: "1px solid #ccc", padding: "10px", maxHeight: "300px", overflowY: "auto" }}>
        {mensajes.map((msg, index) => (
          <p key={index}><strong>{msg.sender}:</strong> {msg.content}</p>
        ))}
      </div>

      {/* Input para enviar mensajes */}
      <div style={{ marginTop: "10px" }}>
        <input
          type="text"
          value={nuevoMensaje}
          onChange={(e) => setNuevoMensaje(e.target.value)}
          placeholder="Escribe tu mensaje..."
        />
        <button onClick={enviarMensaje}>Enviar</button>
      </div>
    </div>
  );
}

export default ChatRoom;
