import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

function HomePage() {
  const [salas, setSalas] = useState([]);
  const [newSala, setNewSala] = useState({ name: "", description: "" });
  const navigate = useNavigate();

  useEffect(() => {
    fetch("http://192.168.65.207:4000/api-sala/room/all")
      .then((res) => res.json())
      .then((data) => setSalas(data))
      .catch((error) => console.error("Error al obtener salas:", error));
  }, []);

  const ingresarSala = (roomId) => {
    navigate(`/chat/${roomId}`);
  };
  

  const handleInputChange = (e) => {
    setNewSala({ ...newSala, [e.target.name]: e.target.value });
  };

  const crearSala = async () => {
    if (!newSala.name.trim()) return;
    const response = await fetch("http://192.168.65.207:4000/api-sala/room/crear", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newSala),
    });

    if (response.ok) {
      const nuevaSala = await response.json();
      setSalas([...salas, nuevaSala]);
      setNewSala({ name: "", description: "" });
    } else {
      console.error("Error al crear sala");
    }
  };

  return (
    <div>
      <h2>Salas de Chat</h2>

      <h3>Crear Nueva Sala</h3>
      <input
        type="text"
        name="name"
        placeholder="Nombre de la sala"
        value={newSala.name}
        onChange={handleInputChange}
      />
      <input
        type="text"
        name="description"
        placeholder="Descripción"
        value={newSala.description}
        onChange={handleInputChange}
      />
      <button onClick={crearSala}>Crear</button>

      <h3>Lista de Salas</h3>
      <ul>
        {salas.map((sala) => (
          <li key={sala._id}>
            {sala.name} - {sala.description}
            <button onClick={() => ingresarSala(sala._id)}>Ingresar</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default HomePage;
