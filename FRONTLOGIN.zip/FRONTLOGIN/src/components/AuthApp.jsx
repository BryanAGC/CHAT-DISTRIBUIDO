import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function AuthApp() {
  const [loginForm, setLoginForm] = useState({ username: "", password: "" });
  const [registerForm, setRegisterForm] = useState({ username: "", email: "", password: "" });
  const [message, setMessage] = useState("");
  const [isLogin, setIsLogin] = useState(true);
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (isLogin) {
      setLoginForm({ ...loginForm, [name]: value });
    } else {
      setRegisterForm({ ...registerForm, [name]: value });
    }
  };

  // Login
  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("http://192.168.65.207:4000/api-auth/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(loginForm),
      });
  
      if (response.ok) {
        const data = await response.json(); // Obtener la respuesta del backend
  
        console.log("Respuesta del login:", data); // Verifica qué datos está devolviendo el servidor
  
        // Asegúrate de que la respuesta incluya 'user.username' y guardarlo en localStorage
        if (data.user && data.user.username) {
          localStorage.setItem("username", data.user.username);
          navigate("/home"); // Redirige a la página de salas
        } else {
          setMessage("El nombre de usuario no fue recibido.");
        }
      } else {
        setMessage("Credenciales incorrectas.");
      }
    } catch (error) {
      setMessage("Error en el inicio de sesión.");
    }
  };
  
  
  

  // Registro
  const handleRegister = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("http://192.168.65.207:4000/api-auth/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(registerForm),
      });

      if (response.ok) {
        setMessage("Registro exitoso. Inicia sesión.");
        setIsLogin(true);
      } else {
        setMessage("Error en el registro.");
      }
    } catch (error) {
      setMessage("Error en el servidor.");
    }
  };

  return (
    <div>
      <h2>{isLogin ? "Login" : "Registro"}</h2>
      <form onSubmit={isLogin ? handleLogin : handleRegister}>
        <input
          type="text"
          name="username"
          placeholder="Usuario"
          value={isLogin ? loginForm.username : registerForm.username}
          onChange={handleChange}
          required
        />
        {!isLogin && (
          <input
            type="email"
            name="email"
            placeholder="Correo electrónico"
            value={registerForm.email}
            onChange={handleChange}
            required
          />
        )}
        <input
          type="password"
          name="password"
          placeholder="Contraseña"
          value={isLogin ? loginForm.password : registerForm.password}
          onChange={handleChange}
          required
        />
        <button type="submit">{isLogin ? "Iniciar sesión" : "Registrar"}</button>
      </form>
      <p>{message}</p>
      <p onClick={() => setIsLogin(!isLogin)} style={{ cursor: "pointer", color: "blue" }}>
        {isLogin ? "¿No tienes cuenta? Regístrate" : "¿Ya tienes cuenta? Inicia sesión"}
      </p>
    </div>
  );
}
