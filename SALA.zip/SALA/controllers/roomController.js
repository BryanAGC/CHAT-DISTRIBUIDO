const Room = require("../models/Room");

// Obtener todas las salas
const getRooms = async (req, res) => {
  try {
    const rooms = await Room.find();
    res.json(rooms);
  } catch (error) {
    res.status(500).json({ error: "Error al obtener las salas" });
  }
};

// Crear una sala nueva
const createRoom = async (req, res) => {
  try {
    const { name } = req.body;
    const newRoom = new Room({ name });
    await newRoom.save();
    res.status(201).json(newRoom);
  } catch (error) {
    res.status(500).json({ error: "Error al crear la sala" });
  }
};

// Eliminar una sala
const deleteRoom = async (req, res) => {
  try {
    const { id } = req.params;
    const room = await Room.findByIdAndDelete(id);
    if (!room) {
      return res.status(404).json({ message: "Sala no encontrada" });
    }
    res.json({ message: "Sala eliminada correctamente" });
  } catch (error) {
    console.error("Error al eliminar sala:", error);
    res.status(500).json({ message: "Error interno del servidor" });
  }
};

// Obtener una sala por ID
const getRoomById = async (req, res) => {
  try {
    const { id } = req.params;
    const room = await Room.findById(id);
    if (!room) {
      return res.status(404).json({ message: "Sala no encontrada" });
    }
    res.json(room);
  } catch (error) {
    console.error("Error al obtener la sala:", error);
    res.status(500).json({ message: "Error interno del servidor" });
  }
};

module.exports = { getRooms, createRoom, deleteRoom, getRoomById };
