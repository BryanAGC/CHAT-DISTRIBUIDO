const express = require("express");
const { getRooms, createRoom, deleteRoom, getRoomById } = require("../controllers/roomController"); // ✅ Agregamos deleteRoom

const router = express.Router();

router.get("/all", getRooms);
router.post("/crear", createRoom);
router.delete("/:id", deleteRoom); // ✅ Ahora deleteRoom está definido correctamente
router.get("/:id",getRoomById); // ✅ Nueva ruta para obtener una sala por ID
module.exports = router;
