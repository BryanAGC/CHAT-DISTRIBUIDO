const express = require("express");
const connectDB = require("./config/db");
const roomsRoutes = require("./routes/rooms");

const app = express();
connectDB();

app.use(express.json());
app.use("/room", roomsRoutes);

const PORT = 5001;
app.listen(PORT, () => console.log(`Servidor en http://localhost:${PORT}`));
