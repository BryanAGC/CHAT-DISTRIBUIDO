const jwt = require("jsonwebtoken");
const JWT_SECRET = "clave_super_secreta";

exports.authMiddleware = (req, res, next) => {
    const token = req.header("Authorization")?.split(" ")[1];

    if (!token) return res.status(401).json({ message: "Acceso denegado" });

    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        req.user = decoded;
        next();
    } catch {
        res.status(401).json({ message: "Token inválido" });
    }
};
