const mongoose = require("mongoose");

const MONGO_URI = "mongodb://admin:password@localhost:27017/authDB?authSource=admin";

const connectDB = async () => {
    try {
        await mongoose.connect(MONGO_URI); // Elimina las opciones obsoletas
        console.log("Conectado a MongoDB :)");
    } catch (error) {
        console.error("Error al conectar a MongoDB:", error);
        process.exit(1);
    }
};

module.exports = connectDB;
