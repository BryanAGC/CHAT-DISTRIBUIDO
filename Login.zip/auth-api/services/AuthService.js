const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const UserRepository = require("../repositories/UserRepository");

const JWT_SECRET = "clave_super_secreta";
const JWT_EXPIRES_IN = "1h";

class AuthService {
    constructor() {
        this.userRepository = new UserRepository();
    }

    async register(username, email, password) {
        const existingUser = await this.userRepository.findByEmail(email);
        if (existingUser) throw new Error("El usuario ya existe");

        const hashedPassword = await bcrypt.hash(password, 10);
        const newUser = await this.userRepository.create({ username, email, password: hashedPassword });

        return { message: "Usuario registrado exitosamente", user: newUser };
    }

    // Actualizamos el login para usar username en lugar de email
    async login(username, password) {
        const user = await this.userRepository.findByUsername(username);
        if (!user) throw new Error("Credenciales inválidas");

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) throw new Error("Credenciales inválidas");

        const token = jwt.sign({ id: user._id }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });

        return { token, user: { id: user._id, username: user.username, email: user.email } };
    }

    async getAllUsers() {
        return await this.userRepository.getAll();
    }

    async deleteUser(userId) {
        const deletedUser = await this.userRepository.deleteUser(userId);
        if (!deletedUser) throw new Error("Usuario no encontrado");
        return { message: "Usuario eliminado exitosamente", user: deletedUser };
    }
}

module.exports = AuthService;
