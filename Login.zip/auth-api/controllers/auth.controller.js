const AuthService = require("../services/AuthService");
const authService = new AuthService();

exports.register = async (req, res) => {
    try {
        const { username, email, password } = req.body;
        const response = await authService.register(username, email, password);
        res.status(201).json(response);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
};

exports.login = async (req, res) => {
    try {
        const { username, password } = req.body;
        const response = await authService.login(username, password);
        res.json(response);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
};

exports.getAllUsers = async (req, res) => {
    try {
        const users = await authService.getAllUsers();
        res.json(users);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.deleteUser = async (req, res) => {
    try {
        // Se espera recibir el ID del usuario como parámetro en la URL
        const { id } = req.params;
        const response = await authService.deleteUser(id);
        res.json(response);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
};