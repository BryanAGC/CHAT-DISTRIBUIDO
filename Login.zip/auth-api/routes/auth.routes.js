// routes/auth.routes.js
const express = require("express");
const { register, login, getAllUsers, deleteUser} = require("../controllers/auth.controller");
const router = express.Router();

router.post("/register", register);
router.post("/login", login);
router.get("/users", getAllUsers); // Ahora debería estar definida
router.delete("/delete/:id", deleteUser);


module.exports = router;
