const User = require("../models/User");

class UserRepository {
    async findByEmail(email) {
        return await User.findOne({ email });
    }

    async findByUsername(username) {
        return await User.findOne({ username });
    }

    async create(user) {
        return await User.create(user);
    }

    async getAll() {
        return await User.find({});
    }

    async deleteUser(userId) {
        return await User.findByIdAndDelete(userId);
    }
}

module.exports = UserRepository;
