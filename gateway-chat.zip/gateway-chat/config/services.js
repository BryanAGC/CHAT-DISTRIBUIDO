const { path } = require("express/lib/application");

const services=[

    {  
        name: "auth",
        url: "http://192.168.65.227:4005",
        path: "/api-auth"

    },

    {
        name: "sala",
        url: "http://192.168.65.195:5001",
        path: "/api-sala"
    },

    {
        name: "chat",
        url: "http://192.168.65.38:3000",
        path: "/api-chat"
    }




]
module.exports = {services}