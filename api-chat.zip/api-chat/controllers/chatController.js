const chatService = require('../services/chatService');

const getMessages = async (req, res) => {
  try {
    const messages = await chatService.getMessages();
    res.status(200).json(messages);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const addMessage = async (req, res) => {
  try {
    const { sender, content, idsala } = req.body;
    const message = await chatService.saveMessage({ sender, content, idsala });
    res.status(201).json(message);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const getMessagesByRoom = async (req, res) => {
  try {
    const { idsala } = req.params; // Obtener el ID de la sala desde la URL
    const messages = await chatService.getMessagesByRoom(idsala);
    res.status(200).json(messages);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

module.exports = { getMessages, addMessage, getMessagesByRoom };
