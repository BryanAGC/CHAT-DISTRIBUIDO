const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors'); // Importa CORS para permitir peticiones entre orígenes
const connectDB = require('./database');
const chatRoutes = require('./routes/chatRoutes');

const app = express();
const server = http.createServer(app);

// Configura CORS para las peticiones REST
app.use(cors({ origin: 'http://localhost:5173' })); // Permitir solicitudes desde el frontend (Vite)

// Configura Socket.io con CORS para permitir conexiones entre frontend y backend
const io = new Server(server, {
  cors: {
    origin: 'http://localhost:5173', // Permite conexiones desde el frontend
    methods: ['GET', 'POST'], // Métodos HTTP permitidos
  },
});

// Conecta la base de datos
connectDB();

// Middleware para interpretar JSON
app.use(express.json());
app.use('/chat', chatRoutes); // Rutas del chat

// Evento de conexión con Socket.io
io.on('connection', (socket) => {
  console.log('Nuevo cliente conectado');

  socket.on('sendMessage', (message) => {
    console.log('Mensaje recibido:', message);
    io.emit('receiveMessage', message); // Emitir el mensaje a todos los clientes conectados
  });

  socket.on('disconnect', () => {
    console.log('Cliente desconectado');
  });
});

// Inicia el servidor
server.listen(3000, () => {
  console.log('Servidor corriendo en el puerto 3000');
});
