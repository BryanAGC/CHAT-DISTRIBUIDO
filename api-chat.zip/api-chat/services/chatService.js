const Message = require('../models/messageModel');

const getMessages = async () => {
  return await Message.find(); // Obtener todos los mensajes
};

const saveMessage = async (messageData) => {
  const newMessage = new Message(messageData);
  return await newMessage.save();
};

const getMessagesByRoom = async (idsala) => {
  return await Message.find({ idsala }); // Filtrar mensajes por idsala
};

module.exports = { getMessages, saveMessage, getMessagesByRoom };
