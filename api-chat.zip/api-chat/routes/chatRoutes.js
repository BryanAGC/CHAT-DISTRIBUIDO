const express = require('express');
const router = express.Router();
const chatController = require('../controllers/chatController');

// Obtener todos los mensajes
router.get('/all', chatController.getMessages);

// Crear un nuevo mensaje
router.post('/crear', chatController.addMessage);

// Obtener mensajes por idsala
router.get('/:idsala', chatController.getMessagesByRoom); // Nueva ruta para filtrar por idsala

module.exports = router;
